
# Funny Modpack

hi friends

i made this for my friends, so that I can update their mods for them :)

https://github.com/aidanfoss/LethalCompanyPack

https://thunderstore.io/c/lethal-company/p/EGK/epicGamerPak/
